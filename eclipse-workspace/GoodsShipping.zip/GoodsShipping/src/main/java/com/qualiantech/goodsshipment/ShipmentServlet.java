package com.qualiantech.goodsshipment;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.Vector;

@WebServlet("/GoodsShipping")
public class ShipmentServlet extends HttpServlet {
    private ShipmentInoutDAO shipmentInoutDAO;

    @Override
    public void init() throws ServletException {
        shipmentInoutDAO = new ShipmentInoutDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Vector<ShipmentInoutVO> shipments = shipmentInoutDAO.getShipmentById(); // Get all shipments without pagination
            request.setAttribute("shipments", shipments);
            PrintWriter out = response.getWriter();
//            request.getRequestDispatcher("/index.html").forward(request, response); // Forward to a JSP for rendering
            out.println(
            		"<html lang=\"en\">\r\n"
            		+ "<head>\r\n"
            		+ "    <meta charset=\"UTF-8\">\r\n"
            		+ "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n"
            		+ "    <title>Goods Shipment</title>\r\n"
            		+ "    <link rel=\"stylesheet\" href=\"style.css\">\r\n"
            		+ "    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css\">\r\n"
            		+ "</head>\r\n"
            		+ "<body>\r\n"
            		+ "    <div class=\"center-h1\">Goods Shipment</div>\r\n"
            		+ "\r\n"
            		+ "    <div class=\"header-actions\">\r\n"
            		+ "        <div class=\"search-filter-options\">\r\n"
            		+ "            <div class=\"search-container\">\r\n"
            		+ "                <i class=\"fas fa-search search-icon\"></i>\r\n"
            		+ "                <input type=\"text1\" placeholder=\"Search...\" class=\"search-input\">\r\n"
            		+ "            </div>\r\n"
            		+ "            <div class=\"filter-dropdown\">\r\n"
            		+ "                <select class=\"dropdown\" id=\"filterDropdown\">\r\n"
            		+ "                    <option value=\"\">Filter by...</option>\r\n"
            		+ "                    <option value=\"documentNo\">Document No</option>\r\n"
            		+ "                    <option value=\"date\">Date</option>\r\n"
            		+ "                    <option value=\"customerNO\">Customer No</option>\r\n"
            		+ "                    <option value=\"customerName\">Customer Name</option>\r\n"
            		+ "                </select>\r\n"
            		+ "            </div>\r\n"
            		+ "        </div>\r\n"
            		+ "        <div class=\"header-buttons\">\r\n"
            		+ "            <button class=\"header-btn\" id=\"addButton\">Add</button>\r\n"
//					+ "			<button class=\"header-btn\" onclick=\"window.location='AddShipment.html'\">Add"
//					+ "			</button>\r\n"
            		+ "            <button class=\"header-btn\" id=\"deleteButton\">Delete</button>\r\n"
            		+ "        </div>\r\n"
            		+ "    </div>\r\n"
            		+ "\r\n"
            		+ "    <!-- Combined Table for Shipments -->\r\n"
            		+ "    <table id=\"combinedTable\">\r\n"
            		+ "        <thead>\r\n"
            		+ "            <tr>\r\n"
            		+ "                <th><input type=\"checkbox\" id=\"selectAllCheckbox\" onclick=\"toggleSelectAll(this)\"></th> \r\n"
            		+ "                <th>Document No</th>\r\n"
            		+ "                <th>Date</th>\r\n"
            		+ "                <th>Customer ID</th>\r\n"
            		+ "                <th>Created By</th>\r\n"
            		+ "                <th>Updated By</th>\r\n"
            		+ "                <th>Actions</th>\r\n"
            		+ "            </tr>\r\n");
            		for (ShipmentInoutVO shipment : shipments)
            		{
            				out.println("<tr>"
            						+		"<td style='vertical-align:middle; text-align:center;width:10;'>"
            						+			"<input type='checkbox' onclick='setSelectAllCheckBox()' value='"+ shipment.getInoutId() +"' class='invoices'>"
            						+		"</td>"
            						+ 		"<td style='vertical-align:middle; text-align:center;padding:0;width:200;'>" + shipment.getDocumentNo() + "</td>"
            						+ 		"<td style='vertical-align:middle; text-align:center;padding:0;width:200;'>" + shipment.getDocumentDate() + "</td>"
            						+ 		"<td style='vertical-align:middle; text-align:center;padding:0;width:200;'>" + shipment.getCustomerId() + "</td>"
            						+ 		"<td style='vertical-align:middle; text-align:center;padding:0;width:200;'>" + shipment.getCreatedby() + "</td>"
            						+ 		"<td style='vertical-align:middle; text-align:center;padding:0;width:200;'>" + shipment.getUpdatedby() + "</td>"
            						+ 		"<td style='vertical-align:middle; text-align:center;width:200;'>"
            						+   	"<div style='display: flex; justify-content: center; gap: 8px; align-items: center;'>"
//            						+       	"<button onclick='\"editRow(this)\' style='margin: 0;'>"
            						+			"<button id=\"editButton\">"
            						+ 				"<i class=\"fas fa-edit\"></i>"
            						+ 			"</button>"
            						+       	"<button onclick='viewShipment(\"" + shipment.getInoutId() + "\",this.parentNode.parentNode.parentNode)' style='margin: 0;'>"
            						+           	"<i class=\"fas fa-eye\"></i>"
            						+       	"</button>"
            						+       	"<button onclick='deleteShipment(\"" + shipment.getInoutId() + "\",this.parentNode.parentNode.parentNode)' style='margin: 0;'>"
            						+           	"<i class=\"fas fa-trash\"></i>"
            						+       	"</button>"
            						+   	"</div>"
            						+	"</td>"
        	                        + 	"</tr>"
        	                        + "</div>");
            		}
            		out.println("</thead>\r\n"
    				+ "        <tbody>\r\n"
            		+ "            <!-- Dynamically filled with shipment data -->\r\n"
            		+ "        </tbody>\r\n"
            		+ "    </table>\r\n"
            		+ "\r\n"
            		+ "   <!-- Add Shipment Form Modal -->\r\n"
            		+ "    <div id=\"addShipmentFormModal\" class=\"modal\">\r\n"
            		+ "        <div class=\"modal-content\">\r\n"
            		+ "            <span class=\"close\">&times;</span>\r\n"
            		+ "            <form id=\"addShipmentForm\">\r\n"
            		+ "                <fieldset>\r\n"
            		+ "                    <legend>Enter Shipment Details</legend>\r\n"
            		+ "                    <label for=\"document_no\">Document No:<span class=\"required\">*</span></label>\r\n"
            		+ "                    <input type=\"text\" id=\"document_no\" name=\"document_no\" disabled><br><br>\r\n"
            		+ "\r\n"
            		+ "                    <label for=\"document_date\">Document Date:<span class=\"required\">*</span></label>\r\n"
            		+ "                    <input type=\"date\" id=\"document_date\" name=\"document_date\" required><br><br>\r\n"
            		+ "\r\n"
            		+ "                    <label for=\"customer_id\">Customer ID:<span class=\"required\">*</span></label>\r\n"
            		+ "                    <input type=\"text\" id=\"customer_id\" name=\"customer_id\" required><br><br>\r\n"
            		+ "                    <fieldset>\r\n"
            		+ "                        <legend>Enter Shipment Line Details</legend>\r\n"
            		+ "                        <label for=\"product_id\">Product ID:</label>\r\n"
            		+ "                        <input type=\"text\" id=\"product_id\" name=\"product_id\"><br><br>\r\n"
            		+ "    \r\n"
            		+ "                        <label for=\"quantity\">Quantity:</label>\r\n"
            		+ "                        <input type=\"number\" id=\"quantity\" name=\"quantity\"><br><br>\r\n"
            		+ "\r\n"
            		+ "                        <div class=\"action-button1\">\r\n"
            		+ "                            <button type=\"button\" id=\"addLineButton\">Add Line</button>\r\n"
            		+ "                            <button type=\"button\" id=\"cancelLineButton\">Cancel</button>\r\n"
            		+ "                        </div>\r\n"
            		+ "                        \r\n"
            		+ "                        <!-- Shipment Line Table -->\r\n"
            		+ "                        <table id=\"lineTable\">\r\n"
            		+ "                            <thead>\r\n"
            		+ "                                <tr>\r\n"
            		+ "                                    <th>Product ID</th>\r\n"
            		+ "                                    <th>Quantity</th>\r\n"
            		+ "                                    <th>Actions</th> \r\n"
            		+ "                                </tr>\r\n"
            		+ "                            </thead>\r\n"
            		+ "                            <tbody>\r\n"
            		+ "                                <!-- Dynamically filled with shipment line data -->\r\n"
            		+ "                            </tbody>\r\n"
            		+ "                        </table>\r\n"
            		+ "                    </fieldset>\r\n"
            		+ "                    <div class=\"action-button2\">\r\n"
            		+ "                        <button type=\"reset\" id=\"resetFormButton\">Reset</button>\r\n"
            		+ "                        <button type=\"submit\" id=\"submitShipment\">Submit</button>\r\n"
            		+ "                    </div>\r\n"
            		+ "                </fieldset>\r\n"
            		+ "            </form>\r\n"
            		+ "        </div>\r\n"
            		+ "    </div>"
            		+ "   <!-- View Shipment Modal -->\r\n"
            		+ "    <div id=\"viewShipmentModal\" class=\"modal\">\r\n"
            		+ "        <div class=\"modal-content\">\r\n"
            		+ "            <span class=\"close-view\">&times;</span>\r\n"
            		+ "            <h2>View Shipment</h2>\r\n"
            		+ "            <form>\r\n"
            		+ "                <label for=\"viewDocumentNo\">Document No:</label>\r\n"
            		+ "                <input type=\"text\" id=\"viewDocumentNo\" disabled>\r\n"
            		+ "\r\n"
            		+ "                <label for=\"viewDocumentDate\">Document Date:</label>\r\n"
            		+ "                <input type=\"text\" id=\"viewDocumentDate\" disabled>\r\n"
            		+ "\r\n"
            		+ "                <label for=\"viewCustomerId\">Customer ID:</label>\r\n"
            		+ "                <input type=\"text\" id=\"viewCustomerId\" disabled>\r\n"
            		+ "\r\n"
            		+ "                <h3>Shipment Lines</h3>\r\n"
            		+ "                <table id=\"viewLineTable\">\r\n"
            		+ "                    <thead>\r\n"
            		+ "                        <tr>\r\n"
            		+ "                            <th>Product ID</th>\r\n"
            		+ "                            <th>Quantity</th>\r\n"
            		+ "                        </tr>\r\n"
            		+ "                    </thead>\r\n"
            		+ "                    <tbody></tbody>\r\n"
            		+ "                </table>\r\n"
            		+ "            </form>\r\n"
            		+ "        </div>\r\n"
            		+ "    </div>\r\n"
            		+ "    \r\n"
            		+ "    \r\n"
            		+ " <!-- Delete Confirmation Modal -->\r\n"
            		+ "<div id=\"deleteConfirmationModal\" class=\"modal\">\r\n"
            		+ "    <div class=\"modal-content\">\r\n"
            		+ "        <span class=\"close\" onclick=\"closeDeleteConfirmation()\">&times;</span>\r\n"
            		+ "        <h2>Delete Confirmation</h2>\r\n"
            		+ "        <p id=\"deleteConfirmationMessage\"></p>\r\n"
            		+ "        <button onclick=\"confirmDelete()\">Confirm</button>\r\n"
            		+ "        <button onclick=\"closeDeleteConfirmation()\">Cancel</button>\r\n"
            		+ "    </div>\r\n"
            		+ "</div>\r\n"
            		+ "\r\n"
            		+ "<!-- Notification Modal -->\r\n"
            		+ "<div id=\"notificationModal\" class=\"modal\">\r\n"
            		+ "    <div class=\"modal-content\">\r\n"
            		+ "        <span class=\"close-notification\" onclick=\"closeDeleteConfirmation()\">&times;</span>\r\n"
            		+ "        <h2>Notification</h2>\r\n"
            		+ "        <p class=\"notification-message\"></p>\r\n"
            		+ "    </div>\r\n"
            		+ "</div>\r\n"
            		+ "\r\n"
            		+ "    <script src=\"script.js\">"
            		+ "</script>\r\n"
            		+ "</body>\r\n"
            		+ "</html>");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if ("add".equals(action)) {
                ShipmentInoutVO shipment = new ShipmentInoutVO();
                shipment.setDocumentNo(request.getParameter("documentNo"));

                
                
                shipment.setDocumentDate(Date.valueOf(request.getParameter("documentDate")));
                shipment.setCustomerId(request.getParameter("customerId"));
                shipment.setCreatedby(request.getParameter("createdBy")); // Ensure this is passed
                shipment.setUpdatedby(request.getParameter("updatedBy")); // Ensure this is passed

                shipmentInoutDAO.addShipment(shipment);
                response.sendRedirect("GoodsShipping"); // Redirect to the GET method
            } else if ("edit".equals(action)) {
                ShipmentInoutVO shipment = new ShipmentInoutVO();
                shipment.setInoutId(request.getParameter("inout_id"));
                shipment.setDocumentNo(request.getParameter("documentNo"));
                shipment.setDocumentDate(Date.valueOf(request.getParameter("documentDate")));
                shipment.setCustomerId(request.getParameter("customer_id"));
                shipment.setUpdatedby(request.getParameter("updatedby")); // Ensure this is passed

                shipmentInoutDAO.updateShipment(shipment);
                response.sendRedirect("GoodsShipping"); // Redirect to the GET method
            } else if ("delete".equals(action)) {
                String inoutId = request.getParameter("inout_id");
                shipmentInoutDAO.deleteShipment(inoutId);
                response.sendRedirect("GoodsShipping"); // Redirect to the GET method
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error");
        }
    }
}
