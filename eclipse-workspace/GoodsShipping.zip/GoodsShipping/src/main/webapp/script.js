// Modal and Table Management
document.getElementById("addButton").onclick = function() {
    document.getElementById("addShipmentFormModal").style.display = "block";
};

document.getElementById("deleteButton").onclick = function() {
    deleteSelectedRows();
};

document.getElementById("editButton").onclick = function() {
    editrow(this.parentNode.parentNode.parentNode);
};

document.querySelector(".close").onclick = function() {
    document.getElementById("addShipmentFormModal").style.display = "none";
};

document.querySelector(".close-view").onclick = function() {
    document.getElementById("viewShipmentModal").style.display = "none";
};

document.querySelector(".close-notification").onclick = function() {
    document.getElementById("notificationModal").style.display = "none";
};

document.getElementById("addLineButton").onclick = function() {
    addLine();
};

document.getElementById("cancelLineButton").onclick = function() {
    clearLineInputs();
};

document.getElementById("addShipmentForm").onsubmit = function(event) {
    event.preventDefault(); // Prevent form submission
    submitShipment();
};

let currentEditRow = null; // Track the row being edited
let currentEditCombinedRow = null; // Track the row being edited in the combined table
let rowToDelete = null; // Store the row to be deleted
let isShipmentLineDelete = false; // Flag for shipment line deletion

// Add or update a line in the shipment
function addLine() {
    const productId = document.getElementById("product_id").value;
    const quantity = document.getElementById("quantity").value;

    // Validation: Check for empty fields
    if (!productId || !quantity) {
        showNotification("Please fill in both product ID and quantity.");
        return;
    }

    const lineTable = document.getElementById("lineTable").getElementsByTagName("tbody")[0];

    if (currentEditRow) {
        // Update existing row
        currentEditRow.cells[0].innerText = productId;
        currentEditRow.cells[1].innerText = quantity;
        currentEditRow = null;
        document.getElementById("addLineButton").innerText = "Add Line";
    } else {
        // Add new row
        const newRow = lineTable.insertRow();
        newRow.insertCell(0).innerText = productId;
        newRow.insertCell(1).innerText = quantity;

        // Add Edit/Delete buttons
        const actionCell = newRow.insertCell(2);
        actionCell.appendChild(createButton('edit-btn', '<i class="fas fa-edit"></i>', () => editLine(newRow)));
        actionCell.appendChild(createButton('delete-btn', '<i class="fas fa-trash"></i>', () => deleteShipmentLine(newRow)));
    }

    clearLineInputs(); // Clear form after adding
}

function createButton(className, iconHtml, clickHandler) {
    const button = document.createElement("button");
    button.className = `action-btn ${className}`;
    button.type = "button"; // Ensure button doesn't submit the form
    button.innerHTML = iconHtml;
    button.onclick = clickHandler;
    return button;
}

// Edit a line in the shipment
function editLine(row) {
    currentEditRow = row;
    document.getElementById("product_id").value = row.cells[0].innerText;
    document.getElementById("quantity").value = row.cells[1].innerText;
    document.getElementById("addLineButton").innerText = "Update Line";
}

// Delete a line in the shipment
function deleteShipmentLine(row) {
    // Set the confirmation message
    const productId = row.cells[0].innerText;
    const quantity = row.cells[1].innerText;

    document.getElementById("deleteConfirmationMessage").innerText = 
        `Are you sure you want to delete this shipment line with Product ID: ${productId} and Quantity: ${quantity}?`;
    
    // Show the confirmation modal
    document.getElementById("deleteConfirmationModal").style.display = "block";

    // Store the row to be deleted
    rowToDelete = row; // Store the reference to the row
    isShipmentLineDelete = true; // Set flag to indicate deletion of a shipment line
}

// Clear inputs for adding/editing lines
function clearLineInputs() {
    document.getElementById("product_id").value = '';
    document.getElementById("quantity").value = '';
}

// Submit the shipment form
function submitShipment() {
    const documentNo = document.getElementById("document_no").value;
    const documentDate = document.getElementById("document_date").value;
    const customerId = document.getElementById("customer_id").value;
	const createdBy = "22";
	const updatedBy = "22";

    const lineTable = document.getElementById("lineTable").getElementsByTagName("tbody")[0];
    const lineRows = lineTable.rows;

    if (lineRows.length === 0) {
        showNotification("Please add at least one product line.");
        return;
    }

    const products = [];
    for (let row of lineRows) {
        const productId = row.cells[0].innerText;
        const quantity = row.cells[1].innerText;
        products.push({ productId, quantity });
    }
	
	var action = "add";
	
	var params = `action=${(action)}&documentNo=${(documentNo)}&documentDate=${documentDate}&customerId=${customerId}&createdBy=${createdBy}&updatedBy=${updatedBy}` ;
	
	products.forEach((product, index) => {
	        params += `&products[${index}][productId]=${(product.productId)}&products[${index}][quantity]=${(product.quantity)}`;
	    });

    if (currentEditCombinedRow) {
        currentEditCombinedRow.cells[1].innerText = documentNo;
        currentEditCombinedRow.cells[2].innerText = documentDate;
        currentEditCombinedRow.cells[3].innerText = customerId;
		currentEditCombinedRow.cells[4].innerText = createdBy;
		currentEditCombinedRow.cells[5].innerText = updatedBy;
        currentEditCombinedRow.dataset.lines = JSON.stringify(products);
        currentEditCombinedRow = null;
    } else {
        const combinedTable = document.getElementById("combinedTable").getElementsByTagName("tbody")[0];
        const newRow = combinedTable.insertRow();
        newRow.insertCell(0).innerHTML = `<input type="checkbox" class="row-checkbox">`;
        newRow.insertCell(1).innerText = documentNo;
        newRow.insertCell(2).innerText = documentDate;
        newRow.insertCell(3).innerText = customerId;
        newRow.insertCell(4).innerText = "22";
        newRow.insertCell(5).innerText = "22";
        newRow.dataset.lines = JSON.stringify(products);

        const actionCell = newRow.insertCell(6);
        actionCell.appendChild(createButton('edit-btn', '<i class="fas fa-edit"></i>', () => editrows(newRow)));
        actionCell.appendChild(createButton('view-btn', '<i class="fas fa-eye"></i>', () => viewShipment(newRow)));
        actionCell.appendChild(createButton('delete-btn', '<i class="fas fa-trash"></i>', () => deleteShipmentRow(newRow)));
    }
	
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function() {
	    if(xhr.readyState == 4 && xhr.status == 200) {
	        var data = xhr.responseText;
			console.log(xhr.responseText);  // This logs the response to the console
	        
	    }
	};

	// Open the POST request to your servlet
	xhr.open("POST", "GoodsShipping", true);
	xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

	xhr.send(params);


    document.getElementById("addShipmentForm").reset();
    clearLineInputs();
    document.getElementById("addShipmentFormModal").style.display = "none";
}

// Edit the shipment row
function editrow(row) {
    currentEditCombinedRow = row;
    const documentNo = row.cells[1].innerText;
    const documentDate = row.cells[2].innerText;
    const customerId = row.cells[3].innerText;

    document.getElementById("document_no").value = documentNo;
    document.getElementById("document_date").value = documentDate;
    document.getElementById("customer_id").value = customerId;

    const products = JSON.parse(row.dataset.lines);
    const lineTable = document.getElementById("lineTable").getElementsByTagName("tbody")[0];
    lineTable.innerHTML = '';

    products.forEach(product => {
        const newRow = lineTable.insertRow();
        newRow.insertCell(0).innerText = product.productId;
        newRow.insertCell(1).innerText = product.quantity;

        const actionCell = newRow.insertCell(2);
        actionCell.appendChild(createButton('edit-btn', '<i class="fas fa-edit"></i>', () => editLine(newRow)));
        actionCell.appendChild(createButton('delete-btn', '<i class="fas fa-trash"></i>', () => deleteShipmentLine(newRow)));
    });

    document.getElementById("addShipmentFormModal").style.display = "block";
}

// View the shipment row
function viewShipment(row) {
    const documentNo = row.cells[1].innerText;
    const documentDate = row.cells[2].innerText;
    const customerId = row.cells[3].innerText;

    document.getElementById("viewDocumentNo").value = documentNo;
    document.getElementById("viewDocumentDate").value = documentDate;
    document.getElementById("viewCustomerId").value = customerId;

    const products = JSON.parse(row.dataset.lines);
    const viewLineTable = document.getElementById("viewLineTable").getElementsByTagName("tbody")[0];
    viewLineTable.innerHTML = '';

    products.forEach(product => {
        const newRow = viewLineTable.insertRow();
        newRow.insertCell(0).innerText = product.productId;
        newRow.insertCell(1).innerText = product.quantity;
    });

    document.getElementById("viewShipmentModal").style.display = "block";
}

// Delete a shipment row
function deleteShipmentRow(row) {
    const documentNo = row.cells[1].innerText;
    const customerId = row.cells[3].innerText;

    document.getElementById("deleteConfirmationMessage").innerText = 
        `Are you sure you want to delete this shipment with Document No: ${documentNo} and Customer ID: ${customerId}?`;

    // Show the confirmation modal
    document.getElementById("deleteConfirmationModal").style.display = "block";

    // Store the row to be deleted
    rowToDelete = row; // Store the reference to the row
    isShipmentLineDelete = false; // Reset flag for shipment line deletion
}

// Confirm deletion
function confirmDelete() {
    const combinedTable = document.getElementById("combinedTable").getElementsByTagName("tbody")[0];
    const lineTable = document.getElementById("lineTable").getElementsByTagName("tbody")[0];

    if (isShipmentLineDelete) {
        // Deleting a single shipment line
        lineTable.deleteRow(rowToDelete.rowIndex - 1); // Adjust index as needed for line table
        showNotification(`Shipment line with Product ID: ${rowToDelete.cells[0].innerText} has been deleted.`);
    } else {
        // Deleting selected shipment rows
        combinedTable.deleteRow(rowToDelete.rowIndex - 1);
        showNotification(`Shipment with Customer ID: ${rowToDelete.cells[3].innerText} and Document No: ${rowToDelete.cells[1].innerText} has been deleted.`);
    }

    rowToDelete = null; // Reset row to delete
    closeDeleteConfirmation();
}

// Delete selected rows
function deleteSelectedRows() {
    const checkboxes = document.querySelectorAll('.row-checkbox');
    let checked = false;
    const rowsToDelete = [];
 
    // Check if at least one checkbox is checked
    checkboxes.forEach((checkbox) => {
    if (checkbox.checked) {
            checked = true;
            const row = checkbox.closest('tr');
            if (row) {
                // Assume Document No is in the second cell (index 1)
                const documentNo = row.cells[1].innerText; // Adjust the index based on your table structure
                // Assume Customer ID is in the third cell (index 2)
                const customerId = row.cells[3].innerText; // Adjust the index based on your table structure
                rowsToDelete.push(`Document No: ${documentNo}, Customer ID: ${customerId}`);
            }
        }
    }); 

    if(!checked) {
    // Alert if no checkbox is selected
    alert('Please select a customer to delete.');
     }else{
    // Confirmation before deletion
    const shipmentIds = rowsToDelete.join("\n"); // Join selected rows for display
    const confirmDelete = confirm(`Are you sure you want to delete the selected customers?\n\n${shipmentIds}`);
    if(confirmDelete) {
    // Delete checked rows
                checkboxes.forEach((checkbox) =>{
    if(checkbox.checked) {
    const row = checkbox.
    closest('tr');
    if(row) {
             row.remove();
            }
        }
    });
    }
}}

function toggleSelectAll(source) {
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i] != source)checkboxes[i].checked = source.checked;
    }
}

// Show notification
function showNotification(message) {
    const notificationModal = document.getElementById("notificationModal");
    notificationModal.querySelector(".notification-message").innerText = message;
    notificationModal.style.display = "block";
}

// Close delete confirmation modal
function closeDeleteConfirmation() {
    document.getElementById("deleteConfirmationModal").style.display = "none";
}
